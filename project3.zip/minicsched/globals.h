/*
 * globals.h
 *
 *  Created on: Nov 9, 2009
 *      Author: Yogesh Arora
 */

#ifndef GLOBALS_H_
#define GLOBALS_H_

#include <stddef.h>
#define INVALID_REG -1
#define R0 0
#define INVALID_SCHEDULE_TIME -1
typedef int Register;
#define DEFAULT_K_VALUE 4

#endif /* GLOBALS_H_ */
